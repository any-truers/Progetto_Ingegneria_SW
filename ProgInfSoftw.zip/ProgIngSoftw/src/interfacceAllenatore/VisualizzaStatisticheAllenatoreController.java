package interfacceAllenatore;

import controller.Controller;

public class VisualizzaStatisticheAllenatoreController implements IVisualizzaStatisticheAllenatore{
	
	private Controller controller;
	
	@Override
	public String visualizzaStatistiche(String username) {
		// TODO Auto-generated method stub
		
		
		return null;
	}

}
