package interfacceAllenatore;


public interface IGestioneAllenatore {
	
	public String getUsername();
	
}
