package dominio;

public enum TipoRicerca {
	
	CATEGORIA,
	NOME_ALLENATORE,
	TITOLO,
	TUTTI
	
}
