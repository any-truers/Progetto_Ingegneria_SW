package dominio;

public enum LivelloDifficolta {
	
	PRINCIPIANTE,
	MEDIO,
	ESPERTO
	
}
