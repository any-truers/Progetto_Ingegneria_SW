package interfacceAmministratore;

public class LogController implements ILog {

}
