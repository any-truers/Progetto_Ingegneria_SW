package interfacceAmministratore;

public interface ILog {

}
