package interfacceCliente;

public class VisualizzaStatisticheController implements IVisualizzaStatistiche {

	@Override
	public String visualizzaStatistiche(String username) {
		// TODO Auto-generated method stub
		return null;
	}

}
