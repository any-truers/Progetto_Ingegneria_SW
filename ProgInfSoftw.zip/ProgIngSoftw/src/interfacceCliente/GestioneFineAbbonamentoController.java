package interfacceCliente;

public class GestioneFineAbbonamentoController implements IGestioneFineAbbonamento{
	
	
	
	@Override
	public boolean rinnovaAbbonamento(String username, String email) {
		// TODO Auto-generated method stub
		return false;
	}

}
