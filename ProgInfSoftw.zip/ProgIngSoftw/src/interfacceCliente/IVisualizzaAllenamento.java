package interfacceCliente;

public interface IVisualizzaAllenamento {
	
	public void guardaAllenamento(String usernameAllenatore, String titoloAllenamento);

}
