package interfacceCliente;

public interface IGestioneFineAbbonamento {
	
	public boolean rinnovaAbbonamento(String username, String email);

}
