package interfacceCliente;

public interface IGestioneCliente {
	
	public String getUsername();
	
}
