package interfacceCliente;

public interface IVisualizzaStatistiche {
	
	public String visualizzaStatistiche(String username);

}
