package interfacceCliente;

public class VisualizzaAllenamentoController implements IVisualizzaAllenamento {

	@Override
	public void guardaAllenamento(String usernameAllenatore, String titoloAllenamento) {
		// TODO Auto-generated method stub

	}

}
